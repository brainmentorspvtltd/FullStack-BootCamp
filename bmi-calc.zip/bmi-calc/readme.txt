BMI = weight (kgs) / height2 (m²)

Height = CM 
CM to Meter = CM / 100
