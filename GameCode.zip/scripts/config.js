export const GAME_WIDTH = 900;
export const GAME_HEIGHT = 300;
export const FRAME_RATE = 70;
export const SPEED = 20;
export const MIN = 1000;
export const MAX = 2000;

// export - wrap in an object , then export {GAME_WIDTH,GAME_HEIGHT}